package com.mycompany.myapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLConectar {

    // Datos de conexión a la base de datos
    private static final String HOST = "localhost";
    private static final String PUERTO = "3306";
    private static final String NAME_DB = "Biblioteca"; // Cambia esto por el nombre de tu base de datos
    private static final String USUARIO = "root"; // Cambia esto por tu usuario de base de datos
    private static final String PASS = "1234"; // Cambia esto por tu contraseña de base de datos
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver"; // Driver JDBC para MySQL

    // Método estático que retorna la conexión a la base de datos
    public static Connection getConectarDB() throws SQLException {
        // URL de conexión a la base de datos
        String databaseURL = "jdbc:mysql://" + HOST + ":" + PUERTO + "/" + NAME_DB + "?useSSL=false";

        try {
            // Cargar el driver de MySQL
            Class.forName(DRIVER);
            // Establecer la conexión y retornarla
            return DriverManager.getConnection(databaseURL, USUARIO, PASS);
        } catch (ClassNotFoundException | SQLException ex) {
            // Si ocurre un error al conectar, lo imprimimos en el stack trace y lanzamos una excepción SQL
            ex.printStackTrace();
            throw new SQLException("Error al conectar a la base de datos.", ex);
        }
    }
}
