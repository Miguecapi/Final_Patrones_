package Backend;

import com.mycompany.myapp.SQLConectar;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/GestionPrestamosServlet")
public class Bibliotecario extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");

        try (Connection connection = SQLConectar.getConectarDB()) {
            String query = "SELECT * FROM Prestamos"; // Selecciona todos los datos de la tabla Prestamos

            try (PreparedStatement stmt = connection.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {

                StringBuilder jsonResponse = new StringBuilder("[");
                while (rs.next()) {
                    if (jsonResponse.length() > 1) {
                        jsonResponse.append(",");
                    }
                    jsonResponse.append("{")
                                .append("\"idPrestamo\":").append(rs.getInt("id_prestamo")).append(",")
                                .append("\"idUsuario\":").append(rs.getInt("id_usuario")).append(",")
                                .append("\"isbn\":\"").append(rs.getString("isbn")).append("\",")
                                .append("\"fechaPrestamo\":\"").append(rs.getDate("fecha_prestamo")).append("\",")
                                .append("\"fechaDevolucion\":\"").append(rs.getDate("fecha_devolucion") != null ? rs.getDate("fecha_devolucion") : "").append("\",")
                                .append("\"estado\":\"").append(rs.getString("estado")).append("\"")
                                .append("}");
                }
                jsonResponse.append("]");
                resp.getWriter().write(jsonResponse.toString());
            }
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"Error al cargar los datos: " + e.getMessage() + "\"}");
        }
    }
}
