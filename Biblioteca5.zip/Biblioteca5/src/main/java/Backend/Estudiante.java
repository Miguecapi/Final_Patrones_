package Backend;

import com.mycompany.myapp.SQLConectar;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

// Estrategia para búsquedas
interface SearchStrategy {

    List<Book> search(String criteria, Connection connection) throws Exception;
}

// Implementación de Strategy para búsqueda por título
class TitleSearchStrategy implements SearchStrategy {

    @Override
    public List<Book> search(String criteria, Connection connection) throws Exception {
        List<Book> results = new ArrayList<>();
        String query = "SELECT titulo, CONCAT(Autores.nombre, ' ', Autores.apellido) AS autor, Generos.nombre_genero AS genero, Libros.isbn, Libros.anio_publicacion "
                + "FROM Libros "
                + "JOIN Autores ON Libros.id_autor = Autores.id_autor "
                + "JOIN Generos ON Libros.id_genero = Generos.id_genero "
                + "WHERE titulo LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + criteria + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(new Book(rs.getString("titulo"), rs.getString("autor"), rs.getString("genero"), rs.getString("isbn"), rs.getInt("anio_publicacion")));
                }
            }
        }
        return results;
    }
}

// Implementación de Strategy para búsqueda por autor
class AuthorSearchStrategy implements SearchStrategy {

    @Override
    public List<Book> search(String criteria, Connection connection) throws Exception {
        List<Book> results = new ArrayList<>();
        String query = "SELECT titulo, CONCAT(Autores.nombre, ' ', Autores.apellido) AS autor, Generos.nombre_genero AS genero, Libros.isbn, Libros.anio_publicacion "
                + "FROM Libros "
                + "JOIN Autores ON Libros.id_autor = Autores.id_autor "
                + "JOIN Generos ON Libros.id_genero = Generos.id_genero "
                + "WHERE CONCAT(Autores.nombre, ' ', Autores.apellido) LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + criteria + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(new Book(rs.getString("titulo"), rs.getString("autor"), rs.getString("genero"), rs.getString("isbn"), rs.getInt("anio_publicacion")));
                }
            }
        }
        return results;
    }
}

// Implementación de Strategy para búsqueda por género
class GenreSearchStrategy implements SearchStrategy {

    @Override
    public List<Book> search(String criteria, Connection connection) throws Exception {
        List<Book> results = new ArrayList<>();
        String query = "SELECT titulo, CONCAT(Autores.nombre, ' ', Autores.apellido) AS autor, Generos.nombre_genero AS genero, Libros.isbn, Libros.anio_publicacion "
                + "FROM Libros "
                + "JOIN Autores ON Libros.id_autor = Autores.id_autor "
                + "JOIN Generos ON Libros.id_genero = Generos.id_genero "
                + "WHERE Generos.nombre_genero LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + criteria + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(new Book(rs.getString("titulo"), rs.getString("autor"), rs.getString("genero"), rs.getString("isbn"), rs.getInt("anio_publicacion")));
                }
            }
        }
        return results;
    }
}

// Clase para representar los libros
class Book {

    private String titulo;
    private String autor;
    private String genero;
    private String isbn;
    private int anio;

    public Book(String titulo, String autor, String genero, String isbn, int anio) {
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.isbn = isbn;
        this.anio = anio;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getGenero() {
        return genero;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getAnio() {
        return anio;
    }
}

// Factory Method para crear estrategias
class SearchStrategyFactory {

    public static SearchStrategy getStrategy(String type) {
        switch (type.toLowerCase()) {
            case "titulo":
                return new TitleSearchStrategy();
            case "autor":
                return new AuthorSearchStrategy();
            case "genero":
                return new GenreSearchStrategy();
            default:
                throw new IllegalArgumentException("Tipo de búsqueda no soportado: " + type);
        }
    }
}

// Servlet principal
@WebServlet("/EstudianteServlet")
public class Estudiante extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String searchType = req.getParameter("tipo");
        String criteria = req.getParameter("criterio");
        List<Book> results = new ArrayList<>();

        resp.setContentType("application/json");
        try (Connection connection = SQLConectar.getConectarDB()) {
            if (criteria == null || criteria.trim().isEmpty()) {
                throw new IllegalArgumentException("El criterio de búsqueda no puede estar vacío.");
            }

            SearchStrategy strategy = SearchStrategyFactory.getStrategy(searchType);
            results = strategy.search(criteria, connection);

            resp.getWriter().write("[");

            for (int i = 0; i < results.size(); i++) {
                Book book = results.get(i);
                resp.getWriter().write("{");
                resp.getWriter().write("\"titulo\":\"" + book.getTitulo() + "\",");
                resp.getWriter().write("\"autor\":\"" + book.getAutor() + "\",");
                resp.getWriter().write("\"genero\":\"" + book.getGenero() + "\",");
                resp.getWriter().write("\"isbn\":\"" + book.getIsbn() + "\",");
                resp.getWriter().write("\"anio\":\"" + book.getAnio() + "\"");
                resp.getWriter().write("}");

                if (i < results.size() - 1) {
                    resp.getWriter().write(",");
                }
            }

            resp.getWriter().write("]");
        } catch (IllegalArgumentException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"Error al realizar la búsqueda: " + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String isbn = req.getParameter("isbn");
        String id_usuario = req.getParameter("id_usuario");

        // Se obtiene la fecha de devolución (esto podría ser un valor fijo o calculado, como +7 días desde el préstamo)
        java.sql.Date fechaDevolucion = new java.sql.Date(System.currentTimeMillis() + 7 ); // Ejemplo: 7 días después del préstamo
        java.sql.Date fechaPrestamo = new java.sql.Date(System.currentTimeMillis());  // Fecha de hoy

        resp.setContentType("application/json");
        try (Connection connection = SQLConectar.getConectarDB()) {
            String query = "INSERT INTO Prestamos (isbn, id_usuario, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, isbn);
                stmt.setString(2, id_usuario);
                stmt.setDate(3, fechaPrestamo);  // Fecha de préstamo
                stmt.setDate(4, fechaDevolucion); // Fecha de devolución

                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    resp.getWriter().write("{\"success\":\"Solicitud de préstamo registrada con éxito.\", \"fecha_prestamo\":\"" + fechaPrestamo + "\", \"fecha_devolucion\":\"" + fechaDevolucion + "\"}");
                } else {
                    resp.getWriter().write("{\"error\":\"No se pudo registrar la solicitud de préstamo.\"}");
                }
            }
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"Error al registrar el préstamo: " + e.getMessage() + "\"}");
        }
    }
}
