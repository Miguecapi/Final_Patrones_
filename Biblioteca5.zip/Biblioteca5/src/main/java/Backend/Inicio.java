package Backend;

import com.mycompany.myapp.SQLConectar;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/InicioServlet")
public class Inicio extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener parámetros del formulario
        String correo = request.getParameter("correo");
        String password = request.getParameter("password");

        try {
            // Obtener la conexión directamente desde SQLConectar
            Connection conexion = SQLConectar.getConectarDB();

            // Consulta SQL para validar las credenciales
            String query = "SELECT tipo_usuario FROM Usuarios WHERE correo = ? AND contraseña = ?";
            PreparedStatement statement = conexion.prepareStatement(query);
            statement.setString(1, correo);
            statement.setString(2, password);

            ResultSet rs = statement.executeQuery();

            // Validar si existe un usuario con las credenciales proporcionadas
            if (rs.next()) {
                // Obtener el tipo de usuario
                String tipoUsuario = rs.getString("tipo_usuario");

                // Redirigir según el tipo de usuario
                switch (tipoUsuario.toLowerCase()) {
                    case "administrador":
                        response.sendRedirect("Administrador.html");
                        break;
                    case "bibliotecario":
                        response.sendRedirect("Bibliotecario.html");
                        break;
                    case "estudiante":
                        response.sendRedirect("Estudiante.html");
                        break;
                    default:
                        // Tipo de usuario desconocido
                        response.sendRedirect("Error.html");
                        break;
                }
            } else {
                // Credenciales inválidas
                response.sendRedirect("ErrorLogin.html");
            }

            // Cerrar recursos
            rs.close();
            statement.close();
        } catch (SQLException e) {
            // Manejo de errores SQL
            response.setContentType("text/html");
            response.getWriter().println("<h1>Error interno</h1>");
            response.getWriter().println("<p>No se pudo procesar tu solicitud. Inténtalo más tarde.</p>");
            e.printStackTrace();
        }
    }

}
