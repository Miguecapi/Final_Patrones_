package Backend;

import com.mycompany.myapp.SQLConectar;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Registro extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Configurar el tipo de respuesta
        response.setContentType("text/html;charset=UTF-8");

        // Capturar y validar los datos del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String correo = request.getParameter("correo");
        String password = request.getParameter("password");
        String tipoUsuario = request.getParameter("tipoUsuario");

        if (!validarCampos(nombre, apellido, correo, password, tipoUsuario)) {
            response.getWriter().write("Todos los campos son obligatorios y deben ser válidos.");
            return;
        }

        // Guardar usuario en la base de datos
        try (Connection conn = SQLConectar.getConectarDB()) {
            if (guardarUsuario(conn, nombre, apellido, correo, password, tipoUsuario)) {
                response.getWriter().write("¡Usuario registrado exitosamente!");
            } else {
                response.getWriter().write("Error al registrar usuario.");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Log para depuración
            response.getWriter().write("Ocurrió un error al procesar la solicitud: " + e.getMessage());
        }
    }

    private boolean validarCampos(String nombre, String apellido, String correo, String password, String tipoUsuario) {
        return nombre != null && !nombre.trim().isEmpty()
                && apellido != null && !apellido.trim().isEmpty()
                && correo != null && correo.matches("^\\S+@\\S+\\.\\S+$")
                && password != null && password.length() >= 6
                && tipoUsuario != null && !tipoUsuario.trim().isEmpty();
    }

    private boolean guardarUsuario(Connection conn, String nombre, String apellido, String correo, String password, String tipoUsuario)
            throws SQLException {
        String sql = "INSERT INTO Usuarios (nombre, apellido, correo, contraseña, tipo_usuario) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, apellido);
            stmt.setString(3, correo);
            stmt.setString(4, password);
            stmt.setString(5, tipoUsuario);
            return stmt.executeUpdate() > 0;
        }
    }
}
