package Backend;

import com.mycompany.myapp.SQLConectar;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/administrador")
public class Administrador extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        String mensaje;

        try (Connection connection = SQLConectar.getConectarDB()) {
            switch (accion) {
                case "agregar":
                    mensaje = agregarLibro(request, connection);
                    break;
                case "modificar":
                    mensaje = modificarLibro(request, connection);
                    break;
                case "eliminar":
                    mensaje = eliminarLibro(request, connection);
                    break;
                default:
                    mensaje = "Acción no válida.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mensaje = "Error en la operación: " + e.getMessage();
        }

        response.setContentType("text/plain");
        response.getWriter().write(mensaje);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (Connection connection = SQLConectar.getConectarDB();
             PrintWriter out = response.getWriter()) {

            response.setContentType("application/json");
            out.print(listarLibros(connection));
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al listar libros.");
        }
    }

    private String agregarLibro(HttpServletRequest request, Connection connection) throws SQLException {
        String titulo = request.getParameter("titulo");
        String autorNombre = request.getParameter("autor_nombre");
        String autorApellido = request.getParameter("autor_apellido");
        String nacionalidad = request.getParameter("nacionalidad");
        String isbn = request.getParameter("isbn");
        String genero = request.getParameter("genero");
        String anio = request.getParameter("anio");

        int idAutor = obtenerIdAutor(connection, autorNombre, autorApellido, nacionalidad);
        int idGenero = obtenerIdGenero(connection, genero);

        String sql = "INSERT INTO Libros (isbn, titulo, id_autor, id_genero, anio_publicacion) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, isbn);
            pstmt.setString(2, titulo);
            pstmt.setInt(3, idAutor);
            pstmt.setInt(4, idGenero);
            pstmt.setString(5, anio);

            if (pstmt.executeUpdate() > 0) {
                return "Libro agregado correctamente.";
            }
        }
        return "Error al agregar el libro.";
    }

    private String modificarLibro(HttpServletRequest request, Connection connection) throws SQLException {
        String isbn = request.getParameter("isbn");
        String titulo = request.getParameter("titulo");
        String autorNombre = request.getParameter("autor_nombre");
        String autorApellido = request.getParameter("autor_apellido");
        String nacionalidad = request.getParameter("nacionalidad");
        String genero = request.getParameter("genero");
        String anio = request.getParameter("anio");

        int idAutor = obtenerIdAutor(connection, autorNombre, autorApellido, nacionalidad);
        int idGenero = obtenerIdGenero(connection, genero);

        String sql = "UPDATE Libros SET titulo = ?, id_autor = ?, id_genero = ?, anio_publicacion = ? WHERE isbn = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, titulo);
            pstmt.setInt(2, idAutor);
            pstmt.setInt(3, idGenero);
            pstmt.setString(4, anio);
            pstmt.setString(5, isbn);

            if (pstmt.executeUpdate() > 0) {
                return "Libro modificado correctamente.";
            }
        }
        return "Error al modificar el libro.";
    }

    private String eliminarLibro(HttpServletRequest request, Connection connection) throws SQLException {
        String isbn = request.getParameter("isbn");
        String sql = "DELETE FROM Libros WHERE isbn = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, isbn);
            if (pstmt.executeUpdate() > 0) {
                return "Libro eliminado correctamente.";
            }
        }
        return "Error al eliminar el libro.";
    }

    private String listarLibros(Connection connection) throws SQLException {
        String sql = "SELECT l.isbn, l.titulo, a.nombre, a.apellido, a.nacionalidad, g.nombre_genero, l.anio_publicacion " +
                     "FROM Libros l " +
                     "JOIN Autores a ON l.id_autor = a.id_autor " +
                     "JOIN Generos g ON l.id_genero = g.id_genero";
        StringBuilder json = new StringBuilder("[");

        try (PreparedStatement pstmt = connection.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                if (json.length() > 1) {
                    json.append(",");
                }
                json.append("{")
                    .append("\"isbn\":\"").append(rs.getString("isbn")).append("\",")
                    .append("\"titulo\":\"").append(rs.getString("titulo")).append("\",")
                    .append("\"autor\":\"").append(rs.getString("nombre")).append(" ").append(rs.getString("apellido")).append("\",")
                    .append("\"nacionalidad\":\"").append(rs.getString("nacionalidad")).append("\",")
                    .append("\"genero\":\"").append(rs.getString("nombre_genero")).append("\",")
                    .append("\"anio\":\"").append(rs.getInt("anio_publicacion")).append("\"")
                    .append("}");
            }
        }
        json.append("]");
        return json.toString();
    }

    private int obtenerIdAutor(Connection connection, String nombre, String apellido, String nacionalidad) throws SQLException {
        String sqlBuscar = "SELECT id_autor FROM Autores WHERE nombre = ? AND apellido = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sqlBuscar)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_autor");
                }
            }
        }

        String sqlInsertar = "INSERT INTO Autores (nombre, apellido, nacionalidad) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sqlInsertar)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            pstmt.setString(3, nacionalidad);
            pstmt.executeUpdate();
        }

        try (PreparedStatement pstmt = connection.prepareStatement(sqlBuscar)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_autor");
                }
            }
        }

        throw new SQLException("Error al obtener o insertar autor.");
    }

    private int obtenerIdGenero(Connection connection, String genero) throws SQLException {
        String sqlBuscar = "SELECT id_genero FROM Generos WHERE nombre_genero = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sqlBuscar)) {
            pstmt.setString(1, genero);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_genero");
                }
            }
        }

        String sqlInsertar = "INSERT INTO Generos (nombre_genero) VALUES (?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sqlInsertar)) {
            pstmt.setString(1, genero);
            pstmt.executeUpdate();
        }

        try (PreparedStatement pstmt = connection.prepareStatement(sqlBuscar)) {
            pstmt.setString(1, genero);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_genero");
                }
            }
        }

        throw new SQLException("Error al obtener o insertar género.");
    }
}
